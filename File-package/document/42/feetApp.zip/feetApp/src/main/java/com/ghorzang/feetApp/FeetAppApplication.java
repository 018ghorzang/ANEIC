package com.ghorzang.feetApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeetAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeetAppApplication.class, args);
	}

}
