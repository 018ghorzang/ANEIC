package com.ghorzang.feetApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeetAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
